/**
 * 
 */
package com.amzn.services.client;

import java.util.Map;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriBuilder;

import org.apache.log4j.Logger;

import com.amzn.services.client.MyClient.RequestType;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;

/**
 * @author abhgarg
 *
 */
public class MyWrapperWoStatusCode {
	
	public static final Logger log = Logger.getLogger(MyClientWrapper.class);
	public MyClient amznClient;
	private String host;
	private Integer port;
	private String fixedPath;
	private String url = null;
	
	/*
	 * @param host - host of the service provider
	 * 
	 * @param port - port number
	 * 
	 * @param fixedPath - a fixed path of the UR
	 * 
	 * @param isRequestWrapped - does request needs root element wrapped for json
	 * request
	 * 
	 * @param isResponseWrapped - does response have root element wrapped
	 */
	public MyWrapperWoStatusCode(String host, Integer port, String fixedPath, boolean isRequestWrapped,
			boolean isResponseWrapped) {
		this.host = host;
		this.port = port;
		this.fixedPath = fixedPath;
		this.url = fixedPath;
		amznClient = new MyClient(isRequestWrapped, isResponseWrapped, false);
	}

	public MyWrapperWoStatusCode(String host, Integer port, String fixedPath, boolean isRequestWrapped,
			boolean isResponseWrapped, boolean enableHttps) {
		this.host = host;
		this.port = port;
		this.fixedPath = fixedPath;
		amznClient = new MyClient(isRequestWrapped, isResponseWrapped, enableHttps);
	}

	/**
	 *
	 * @param host
	 *            - host of the service provider
	 * @param fixedPath
	 * 
	 * @param isRequestWrapped
	 *            - does request needs root element wrapped for json request
	 * @param isResponseWrapped
	 *            - does response have root element wrapped
	 */
	public MyWrapperWoStatusCode(String host, String fixedPath, boolean isRequestWrapped, boolean isResponseWrapped) {
		this(host, 80, fixedPath, isRequestWrapped, isResponseWrapped);
	}
	
	/**
	 * Sends request
	 * 
	 * @param amznClientRequest
	 */
	public void sendRequest(MyClientRequest<?> amznClientRequest) throws Exception {
		if (amznClientRequest == null) {
			throw new IllegalArgumentException("Null value supplied");
		}
		sendRequest(amznClientRequest.getDynamicPath(), amznClientRequest.getDynamicPathVariable(),
				amznClientRequest.getQueryParameter(), amznClientRequest.getRequest(),
				amznClientRequest.getContentType(), amznClientRequest.getRequestType(),
				amznClientRequest.getHeaders(),
				amznClientRequest.isExpectingEmptyResponseBody());
	}
	
	public <T> T sendRequest(MyClientRequest<?> amznClientRequest,
			Class<T> responseClass) throws Exception {
		if (amznClientRequest == null) {
			throw new IllegalArgumentException("Null value supplied");
		}
		return sendRequest(amznClientRequest.getDynamicPath(),
				amznClientRequest.getDynamicPathVariable(),
				amznClientRequest.getQueryParameter(),
				amznClientRequest.getRequest(), responseClass,
				amznClientRequest.getContentType(),
				amznClientRequest.getAcceptType(),
				amznClientRequest.getRequestType(),
				amznClientRequest.getHeaders());
	}
	
	/**
	 * 
	 * @param path
	 *            - the path (excluding the fixed path, and query parameter)
	 * @param pathVariables
	 *            - Map of Key value which will be replaced in the path
	 *            supplied, e.g. if path is $PID/validateLoyaltyCards and if
	 *            pathVariables is provided with PID as key and value as 123 The
	 *            URL will replace $PID and will form 123/validateLoyaltyCards
	 * @param queryParameter
	 *            - Query request URL parameter to be supplied
	 * @param request
	 *            - request object
	 * @param responseClass
	 *            - Expected response class
	 * @param contentType
	 *            - contentType of request body
	 * @param acceptMediaType
	 *            - accept Type of response body
	 * @param requestType
	 *            - type of the request
	 * @param expectedStatusCode
	 *            - expected status code from response
	 * @param headers
	 *            - request headers
	 * @return
	 */
	public <T> T sendRequest(String path, Map<String, String> pathVariables,
			Map<String, Object> queryParameter, Object request,
			Class<T> responseClass, MediaType contentType,
			MediaType acceptMediaType, RequestType requestType,
			Map<String, Object> headers)
			throws Exception {
		// long startTime;
		// long stopTime;
		// int indexStart = url.indexOf("/") + 1;
		// startTime = System.nanoTime();
		ResponseMaster<T> responseMaster = sendRequest(path, pathVariables,
				queryParameter, request, responseClass, contentType,
				acceptMediaType, requestType, headers,
				false);
		// stopTime = System.nanoTime();
		// System.out.println(
		// "Time measured for " + url.substring(indexStart) + " is : " +
		// (stopTime - startTime) / 1000000 + " ms");
		return responseMaster.getResponseObject();
	}
	
	public <T> ResponseMaster<T> sendRequest(String path,
			Map<String, String> pathVariables,
			Map<String, Object> queryParameter, Object request,
			Class<T> responseClass, MediaType contentType,
			MediaType acceptMediaType, RequestType requestType,
			Map<String, Object> headers,
			boolean responseHeaderExpected) throws Exception {
		if (responseClass == null) {
			throw new Exception("Response Class should not be null");
		}
		ResponseMaster<T> result = null;
		T resultEntity = null;
		MultivaluedMap<String, String> resultHeaders = null;
		long startTime;
		long stopTime;
		int indexStart = url.indexOf("/") + 1;
		startTime = System.nanoTime();
		ClientResponse clientResponse = sendRequest(path, pathVariables,
				queryParameter, request, contentType, acceptMediaType,
				requestType, headers);
		stopTime = System.nanoTime();
		System.out.println("Time measured for " + url.substring(indexStart)
				+ " is : " + (stopTime - startTime) / 1000000 + " ms");
		clientResponse.bufferEntity();
		try {
			resultEntity = clientResponse.getEntity(responseClass);
			if (responseHeaderExpected) {
				resultHeaders = clientResponse.getHeaders();
			}
			result = new ResponseMaster<T>(resultEntity, resultHeaders);
		} catch (ClientHandlerException ex) {
			throw new Exception(
					"Unable to unmarshal response, expected :"
							+ responseClass.getCanonicalName()
							+ " received message: " + getError(clientResponse)
							+ ex.getMessage());
		} catch (WebApplicationException ex) {
			throw new Exception(
					"Unable to unmarshal response, expected :"
							+ responseClass.getCanonicalName()
							+ " received message : " + getError(clientResponse)
							+ ex.getMessage());
		} finally {
			clientResponse.close();
		}
		return result;
	}
	
	private ClientResponse sendRequest(String path,
			Map<String, String> pathVariables,
			Map<String, Object> queryParameter, Object request,
			MediaType contentType, MediaType acceptMediaType,
			RequestType requestType, 
			Map<String, Object> headers) throws Exception {
		String url = getUrl(path, pathVariables, queryParameter);
		if (contentType == null) {
			throw new Exception(
					"contentType should not be null : contentType: "
							+ contentType);
		}
		if (acceptMediaType == null) {
			throw new Exception(
					"acceptMediaType should not be null : acceptMediaType: "
							+ acceptMediaType);
		}
		if (requestType == null) {
			throw new Exception(
					"requestType should not be null : requestType: "
							+ requestType);
		}
		ClientResponse clientResponse = amznClient.sendRequest(url, request,
				contentType, acceptMediaType, requestType, headers);
		
		return clientResponse;
	}
	
	/**
	 * 
	 * @param path
	 *            - the path (excluding the fixed path, and query parameter)
	 * @param pathVariables
	 *            - Map of Key value which will be replaced in the path
	 *            supplied, e.g. if path is $PID/validateLoyaltyCards and if
	 *            pathVariables is provided with PID as key and value as 123 The
	 *            URL will replace $PID and will form 123/validateLoyaltyCards
	 * @param queryParameter
	 *            - Query request URL parameter to be supplied
	 * @param request
	 *            - request object
	 * @param contentType
	 *            - contentType of request body
	 * @param requestType
	 *            - type of the request
	 * @param expectedStatusCode
	 *            - expected status code from response
	 * @param headers
	 *            - request headers
	 * @param expectingEmptyResponseBody
	 *            - expected status code from response
	 */
	public void sendRequest(String path, Map<String, String> pathVariables,
			Map<String, Object> queryParameter, Object request,
			MediaType contentType, RequestType requestType,
			Map<String, Object> headers,
			boolean expectingEmptyResponseBody) throws Exception {
		ClientResponse clientResponse = sendRequest(path, pathVariables,
				queryParameter, request, contentType, MediaType.WILDCARD_TYPE,
				requestType, headers);
		if (expectingEmptyResponseBody) {
			if (clientResponse.hasEntity()) {
				clientResponse.bufferEntity();
				String errorMsg = getError(clientResponse);
				throw new Exception(
						"No response was expected, but got " + errorMsg);
			}
		}
	}
	
	private String getError(ClientResponse clientResponse) {
		try {
			clientResponse.getEntityInputStream().reset();
			return clientResponse.getEntity(String.class);
		} catch (Exception e) {
			return null;
		}
	}

	private String getUrl(String pathResourceUrl, Map<String, String> webResourceParameters,
			Map<String, Object> queryParam) {
		String webResourceUrl = pathResourceUrl;
		if (pathResourceUrl != null && webResourceParameters != null) {
			for (Map.Entry<String, String> entry : webResourceParameters.entrySet()) {
				webResourceUrl = webResourceUrl.replace("$" + entry.getKey(), entry.getValue());
			}
		}

		UriBuilder uriBuilder = UriBuilder.fromUri(fixedPath);
		uriBuilder.scheme("http");
		uriBuilder.host(host);
		uriBuilder.port(port);
		if (webResourceUrl != null) {
			uriBuilder.path(webResourceUrl);
		}
		if (queryParam != null) {
			for (Map.Entry<String, Object> entry : queryParam.entrySet()) {
				uriBuilder.queryParam(entry.getKey(), entry.getValue());
			}
		}

		String url = uriBuilder.build().toString();
		return url;
	}
	
}
