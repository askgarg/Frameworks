/**
 * 
 */
package com.amzn.automation.api.rest.json.utils;

/**
 * @author abhgarg
 *
 */
public interface IResponseStatusAPIKeys {

	public static String STATUS_MESSAGE_KEY_BACKEND = "statusMessage";
	public static String STATUS_CODE_KEY_BACKEND = "statusCode";

	public static String STATUS_MESSAGE_KEY = "statusMessage";
	public static String STATUS_CODE_KEY = "statusCode";
	
}
