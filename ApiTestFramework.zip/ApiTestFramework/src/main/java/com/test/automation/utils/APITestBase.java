/**
 * 
 */
package com.amzn.automation.utils;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.amzn.automation.api.rest.RestTestHelper;
import com.amzn.automation.common.utils.CommonUtil;

/**
 * @author abhgarg
 *
 */
public abstract class APITestBase {

	public static final Logger log = Logger.getLogger(APITestBase.class);

	public static HashMap<String, String> apiProperties = null;
	public static HashMap<String, String> envProperties = null;
	protected static final String DELIMITTER = ":";
	public static HashMap<String, String> suiteProperties = null;
	public static String defaultAuthString = null;
	public static String defaultHost = null;
	public static Integer defaultPort = null;

	static {

		try {
			loadNSetEnvInfo();
			initializeCustomDataIfAny();
			initializeDefaultData();
			logExecutionEnvInfo();
			RestTestHelper.initializeRequiredvariables();
		} catch (Exception e) {
			log.error("Env Settings :APITestBase --->  Exception occured while intialization/loading :" + e);
			e.printStackTrace();
		}
	}

	private static void loadNSetEnvInfo() {
		apiProperties = CommonUtil.getData(IDataInilizer.API_INPUT_PROPERTIESFILEPATH);
		suiteProperties = CommonUtil.getData(IDataInilizer.API_SUITE_PROPERTIESFILEPATH);

		if (null == apiProperties || null == suiteProperties) {
			log.error("api/env properties file not found....So exiting");
			System.exit(0);
		}

		if (null == System.getProperty(IDataInilizer.KEY_ENV)) {
			log.warn("You Not Set the Environment.... So ,Taking Default Environment as DEVO.");
			System.setProperty(IDataInilizer.KEY_ENV, IDataInilizer.KEY_ENV_DEVO);
		}

		if (System.getProperty(IDataInilizer.KEY_ENV).equalsIgnoreCase(IDataInilizer.KEY_ENV_DEVO)) {
			envProperties = CommonUtil.getData(IDataInilizer.API_DEVO_PROPERTIESFILEPATH);
		} else if (System.getProperty(IDataInilizer.KEY_ENV).equalsIgnoreCase(IDataInilizer.KEY_ENV_PROD)) {
			envProperties = CommonUtil.getData(IDataInilizer.API_PROD_PROPERTIESFILEPATH);
		} else {
			log.error("Unable to find the property provided So,System will exist from execution: Provided>"
					+ System.getProperty(IDataInilizer.KEY_ENV));
			System.exit(0);
		}
	}

	private static void initializeCustomDataIfAny() {
		System.out.println("initializeCustomDataIfAny");
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>");
		if (null != System.getProperty("CUSTOM_EXCEL_PATH") && !System.getProperty("CUSTOM_EXCEL_PATH").isEmpty()) {
			suiteProperties.put("inputexceldatafilepath", System.getProperty("CUSTOM_EXCEL_PATH").trim());
			System.out.println("CUSTOM_EXCEL_PATH FOUND :" + suiteProperties.get("inputexceldatafilepath").trim());
			log.info("CUSTOM_EXCEL_PATH FOUND :" + suiteProperties.get("inputexceldatafilepath").trim());
		}
		if (null != System.getProperty("CUSTOM_SHEET_NAME") && !System.getProperty("CUSTOM_SHEET_NAME").isEmpty()) {
			suiteProperties.put("excelDatasheetname", System.getProperty("CUSTOM_SHEET_NAME").trim());
			System.out.println("CUSTOM_SHEET_NAME FOUND :" + suiteProperties.get("excelDatasheetname"));
			log.info("CUSTOM_SHEET_NAME FOUND :" + suiteProperties.get("excelDatasheetname"));
		}

		/*
		 * if (null != System.getProperty("CUSTOM_DEFAULT_HOST") &&
		 * !System.getProperty("CUSTOM_DEFAULT_HOST").isEmpty()) {
		 * envProperties.put("backend_host",
		 * System.getProperty("CUSTOM_DEFAULT_HOST").trim());
		 * System.out.println("CUSTOM_DEFAULT_HOST FOUND :" +
		 * envProperties.get("backend_host")); log.info("CUSTOM_DEFAULT_HOST FOUND :" +
		 * envProperties.get("backend_host")); }
		 */

		/*
		 * if (null != System.getProperty("CUSTOM_DEFAULT_PORT") &&
		 * !System.getProperty("CUSTOM_DEFAULT_PORT").isEmpty()) {
		 * envProperties.put("backend_port",
		 * System.getProperty("CUSTOM_DEFAULT_PORT").trim());
		 * System.out.println("CUSTOM_DEFAULT_PORT FOUND :" +
		 * envProperties.get("backend_port")); log.info("CUSTOM_DEFAULT_PORT FOUND :" +
		 * envProperties.get("backend_port"));
		 * 
		 * }
		 */

		System.out.println(">>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
	}

	private static void initializeDefaultData() throws Exception {

		if (null == System.getProperty("CUSTOM_DEFAULT_HOST") || System.getProperty("CUSTOM_DEFAULT_HOST").isEmpty()) {
			System.out.println("CUSTOM_DEFAULT_HOST Not defined,So defaultHost is initialized");
			defaultHost = getEnvPropertyValue(getEnvPropertyValue("default_host_key"));
			System.out.println("CUSTOM_DEFAULT_HOST Not defined,So defaultHost is initialized,defaultHost:" + defaultHost);
		} else {
			defaultHost = envProperties.get("backend_host");
			log.warn("WARNING!!!!!..You provided custom HOST Through System Property:" + defaultHost);
		}

		if (null == System.getProperty("CUSTOM_DEFAULT_PORT") || System.getProperty("CUSTOM_DEFAULT_PORT").isEmpty()) {
			defaultPort = Integer.parseInt(getEnvPropertyValue(getEnvPropertyValue("default_port_key")));
		} else {
			defaultPort = Integer.parseInt(envProperties.get("default_port"));
			log.warn("WARNING!!!!!..You provided custom  PORT Through System Property:" + defaultPort);
		}

		if (null == defaultHost || null == defaultPort) {
			log.warn("WARNING!!!!!..Default Host/Port is null..So,APIs with Default Host/Port wont Work  :"
					+ defaultHost);
		} else {
			log.info("WARNING!!!!!.. provided  DEFAULT HOST and DEFAULT PORT  >>>>> HOST:PORT >" + defaultHost + ":"
					+ defaultPort);
		}
	}

	private static void logExecutionEnvInfo() {
		log.info("***********************************API AUTOMATION**************************");
		log.info("Environment Set #####:" + System.getProperty(IDataInilizer.KEY_ENV));
		log.info("Default/Custom Host       :" + defaultHost);
		log.info("Default/Custom Port       :" + defaultPort);
		log.info("***************************************************************************");
	}

	public static String getEnvPropertyValue(String propertyKey) throws Exception {
		return getValueFromPropertyMap(propertyKey, envProperties);
	}

	public static String getSuitePropertyValue(String propertyKey) throws Exception {
		return getValueFromPropertyMap(propertyKey, suiteProperties);
	}

	private static String getValueFromPropertyMap(String propertyKey, HashMap<String, String> propertyMap)
			throws Exception {
		if (null == propertyKey || null == propertyMap) {
			log.error("Exception: Key/propertyFileMap is null");
			throw new Exception("Key/propertyFileMap is null");
		}
		return propertyMap.get(propertyKey).trim();
	}

}
