/**
 * 
 */
package com.amzn.automation.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

/**
 * @author abhgarg
 *
 */
public interface ITestDataReader {
	
	public Object[][] getDataSetTestDataMinimal(String dataGroupName);

	public Object[][] getDataSetTestData(String dataGroupName);

	public Object[][] getDataSetTestDataWithExpectedFields(String dataGroupName);

	public Integer[] getTestDataGroupStartAndEndRow(String dataGroup);

	public ArrayList<String> getDataSetNames(String dataGroup);

	public LinkedHashMap<String, String> getTestData(String dataGroupName,
			String columnHeader);

	public HashMap<String, Integer[]> getTestDataGroupInfo();

}
