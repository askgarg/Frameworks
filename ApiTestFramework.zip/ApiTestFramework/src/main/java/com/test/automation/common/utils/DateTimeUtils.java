/**
 * 
 */
package com.amzn.automation.common.utils;

import java.time.LocalDateTime;
import java.time.ZoneId;

import org.apache.log4j.Logger;

/**
 * @author abhgarg
 *
 */
public class DateTimeUtils {
	
	private final static Logger LOG = Logger.getLogger(DateTimeUtils.class);

	public enum FORMAT {
		LOCAL_FOPRMAT("yyyy-MM-dd'T'HH:mm:ss.S"), 
		STANDARD_DATE_FORMAT("yyyy-MM-dd HH:mm:ss.S"), 
		EPOCH_SECONDS_FORMAT("EPOCH_SECONDS_FORMAT"), 
		EPOCH_MILLISECONDS_FORMAT("EPOCH_MILLISECONDS_FORMAT");
		private FORMAT(String data) {
			/* no code constructor */ }
	}

	public static void sleepWait(long milliSeconds) {
		try {
			LOG.info("Waiting for " + milliSeconds + "milli seconds.");
			Thread.sleep(milliSeconds);
		} catch (Exception e) {
			LOG.error("Error in wait module. " + e.getMessage());
			return;
		}
	}

	private static String format(LocalDateTime dateObject, DateTimeUtils.FORMAT dateFormat) {
		if (dateFormat.equals(FORMAT.STANDARD_DATE_FORMAT)) {
			String date[] = dateObject.toString().split("T");
			LOG.trace("Returning date as :: " + date[0] + " " + date[1]);
			return date[0] + " " + date[1];
		} else if (dateFormat.equals(FORMAT.EPOCH_MILLISECONDS_FORMAT)) {
			LOG.trace("Returning date as :: " + dateObject.atZone(ZoneId.systemDefault()).toEpochSecond() * 1000);
			return (dateObject.atZone(ZoneId.systemDefault()).toEpochSecond() * 1000) + "";
		} else if (dateFormat.equals(FORMAT.LOCAL_FOPRMAT)) {
			LOG.trace("Returning date as :: " + dateObject.toString());
			return dateObject.toString();
		} else if (dateFormat.equals(FORMAT.EPOCH_SECONDS_FORMAT)) {
			LOG.trace("Returning date as :: " + dateObject.atZone(ZoneId.systemDefault()).toEpochSecond());
			return dateObject.atZone(ZoneId.systemDefault()).toEpochSecond() + "";
		}
		return null;
	}

	/**
	 * @param days
	 * @param dateFormat
	 * @return Date in Future based on number of days passed
	 */
	public static String getFutureDateByDaysFromToday(int days, FORMAT dateFormat) {
		return format(getCurrentDate().plusDays(days), dateFormat);
	}

	/**
	 * @param hours
	 * @param dateFormat
	 * @return Date in Future based on number of hours passed
	 */
	public static String getFutureDateByHoursFromToday(int hours, FORMAT dateFormat) {
		return format(getCurrentDate().plusHours(hours), dateFormat);
	}

	/**
	 * @param minutes
	 * @param dateFormat
	 * @return Date in Future based on number of hours passed
	 */
	public static String getFutureDateByMinutesFromToday(int minutes, FORMAT dateFormat) {
		return format(getCurrentDate().plusMinutes(minutes), dateFormat);
	}

	/**
	 * @param minutes
	 * @param dateFormat
	 * @return Date in Past based on number of minutes passed
	 */
	public static String getPastDateByMinutesFromToday(int minutes, FORMAT dateFormat) {
		return format(getCurrentDate().minusMinutes(minutes), dateFormat);
	}
	
	/**
	 * @param hours
	 * @param dateFormat
	 * @return Date in Past based on number of hours passed
	 */
	public static String getPastDateByHoursFromToday(int hours, FORMAT dateFormat) {
		return format(getCurrentDate().minusHours(hours), dateFormat);
	}

	/**
	 * @param days
	 * @param dateFormat
	 * @return Date in Past based on number of days passed
	 */
	public static String getPastDateByDaysFromToday(int days, FORMAT dateFormat) {
		return format(getCurrentDate().minusDays(days), dateFormat);
	}

	/**
	 * @param dateOfMonth
	 * @param month
	 * @param year
	 * @param hour
	 * @param minute
	 * @param dateFormat
	 * @return Date in Past based on number of days passed
	 */
	public static String createDate(int dateOfMonth, int month, int year, int hour, int minute, FORMAT dateFormat) {
		return format(getCurrentDate().withDayOfMonth(dateOfMonth).withMonth(month).withYear(year).withHour(hour)
				.withMinute(minute).withSecond(1), dateFormat);
	}

	/**
	 * @param dateFormat
	 * @return String Object containing Date Time based on input dateObject
	 */
	public static String getCurrentDateTime(FORMAT dateFormat) {
		return format(getCurrentDate(), dateFormat);
	}

	/**
	 * @return LocalDateTime Object containing current Date Time
	 */
	private static LocalDateTime getCurrentDate() {
		return LocalDateTime.now();
	}

}
