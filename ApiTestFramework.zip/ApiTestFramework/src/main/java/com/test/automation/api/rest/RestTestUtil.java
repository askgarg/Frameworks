/**
 * 
 */
package com.amzn.automation.api.rest;

import java.io.IOException;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParseException;

import com.amzn.automation.common.utils.APIUtils;
import com.amzn.services.client.MyClient;
import com.amzn.services.client.MyClientRequest;
import com.amzn.services.client.MyClientWrapper;

/**
 * @author abhgarg
 *
 */
public class RestTestUtil extends RestTestHelper {

	public static final Logger log = Logger.getLogger(RestTestUtil.class);

	public static JsonNode sendData(String apiKey, JsonNode inputRequest) throws Exception {
		if (null == defaultHost || null == defaultPort) {
			log.error("defaultHost/defaultHost is null..please check.ensure defaultHost and  defaultport initialized");
			return null;
		}
		return invokeClient(defaultHost, defaultPort, apiKey, inputRequest);
	}

	public static JsonNode sendData(String apiKey, JsonNode inputRequest, Map<String, Object> headers)
			throws Exception {
		if (null == defaultHost || null == defaultPort) {
			log.error("defaultHost/defaultHost is null..please check.ensure defaultHost and  defaultport initialized");
			return null;
		}
		return invokeClient(defaultHost, defaultPort, apiKey, inputRequest, headers);
	}

	private static JsonNode invokeClient(String host, Integer port, String apiKey, JsonNode jsonRequestData)
			throws Exception {
		String value;
		String requestType = null;
		String requestUrl = null;
		try {
			value = apiProperties.get(apiKey.trim());
			String requestData[] = value.split("=");

			if (null == requestData) {
				System.out.println("API not added to properties");
				log.error("API Not Defined in api.properties.");
				return null;
			}
			requestType = requestData[0].trim();
			requestUrl = requestData[1].trim();
			log.info("API TYPE and  URL :" + requestType + " , " + requestUrl);
			log.info("****************************************");

			return execute(host, port, requestUrl, requestType, jsonRequestData);
		} catch (Exception e) {
			log.error(e.getMessage() + ">> invokeClient()   ECZZEPTION IZ :" + e);
			e.printStackTrace();
		}
		return null;
	}

	private static JsonNode invokeClient(String host, Integer port, String apiKey, JsonNode jsonRequestData,
			Map<String, Object> headers) throws Exception {
		String value;
		String requestType = null;
		String requestUrl = null;
		try {
			value = apiProperties.get(apiKey.trim());
			String requestData[] = value.split("=");

			if (null == requestData) {
				System.out.println("API not added to properties");
				log.error("API Not Defined in api.properties.");

				return null;
			}
			requestType = requestData[0].trim();
			requestUrl = requestData[1].trim();
			log.info("API TYPE and  URL :" + requestType + " , " + requestUrl);
			log.info("****************************************");

			return execute(host, port, requestUrl, requestType, jsonRequestData, headers);
		} catch (Exception e) {
			log.error(e.getMessage() + ">> invokeClient()   ECZZEPTION IZ :" + e);
			e.printStackTrace();
		}
		return null;

	}

	private static JsonNode execute(String host, Integer port, String requestUrl, String requestType,
			JsonNode jsonRequestData) throws JsonParseException, IOException, Exception {

		MyClientWrapper client = new MyClientWrapper(host, port, requestUrl, false, false);
		MyClientRequest<Object> request = new MyClientRequest<Object>();
		request.setAcceptType(MediaType.APPLICATION_JSON_TYPE);
		request.setContentType(MediaType.APPLICATION_JSON_TYPE);
		/*
		 * Map<String, Object> map = new HashMap<String, Object>(); if (null !=
		 * someHeader) { log.debug("Header1 set :" + someHeader);
		 * request.setHeaders(getRequestHeaders(map, "tid", someHeader)); }
		 */
		switch (requestType.trim()) {
		case "POST":
			request.setRequestType(MyClient.RequestType.POST);
			break;
		case "GET":
			request.setRequestType(MyClient.RequestType.GET);
			break;

		case "PUT":
			request.setRequestType(MyClient.RequestType.PUT);
			break;
		case "DELETE":
			request.setRequestType(MyClient.RequestType.DELETE);
			break;
		default:
			break;
		}
		// request.setExpectedStatusCode(200);
		request.setRequest(jsonRequestData);
		// return client.sendRequest(request, JsonNode.class);
		log.info("client requestData:" + jsonRequestData);
		String resp = client.sendRequest(request, String.class);
		log.info("client reponse:" + resp);
		JsonNode response = APIUtils.convertStringtoJSON(resp);
		log.info("client jsonFormat reponse:" + response);
		return response;
	}

	private static JsonNode execute(String host, Integer port, String requestUrl, String requestType,
			JsonNode jsonRequestData, Map<String, Object> headers) throws Exception {

		MyClientWrapper client = new MyClientWrapper(host, port, requestUrl, false, false);
		MyClientRequest<Object> request = new MyClientRequest<Object>();
		// request.setAcceptType(MediaType.APPLICATION_JSON_TYPE);
		request.setContentType(MediaType.APPLICATION_JSON_TYPE);
		request.setHeaders(headers);

		switch (requestType.trim()) {
		case "POST":
			request.setRequestType(MyClient.RequestType.POST);
			break;
		case "GET":
			request.setRequestType(MyClient.RequestType.GET);
			break;

		case "PUT":
			request.setRequestType(MyClient.RequestType.PUT);
			break;
		case "DELETE":
			request.setRequestType(MyClient.RequestType.DELETE);
			break;
		default:
			break;
		}
		request.setRequest(jsonRequestData);
		log.info("client requestData:" + jsonRequestData);
		String resp = client.sendRequest(request, String.class);
		log.info("client  reponse:" + resp);
		JsonNode response = APIUtils.convertStringtoJSON(resp);
		log.info("client jsonFormat reponse:" + response);
		return response;
	}

	@SuppressWarnings("unused")
	private static Map<String, Object> getRequestHeaders(Map<String, Object> map, String key, String value) {
		map.put(key, value);
		return map;
	}

	public void getObject(JsonNode jsonNode, String tillParentPath, String[] check) {
		String[] anscestors = tillParentPath.split(".");
		String field = "";
		for (String anscestor : anscestors) {
			field += ".get(" + anscestor + ")";
		}
		String a = jsonNode + field.toString();
		System.out.println(a);

	}

}
