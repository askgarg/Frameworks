/**
 * 
 */
package com.amzn.automation.api.rest;

/**
 * @author abhgarg
 *
 */
public enum JsonValidationLevels {
	HIGH_LEVEL, DETAILED_LEVEL
}
