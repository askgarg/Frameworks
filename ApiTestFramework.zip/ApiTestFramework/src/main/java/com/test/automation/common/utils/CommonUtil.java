/**
 * 
 */
package com.amzn.automation.common.utils;

import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Properties;

/**
 * @author abhgarg
 *
 */
public class CommonUtil {

	public static HashMap<String, String> getData(String propertiesFile) {
		HashMap<String, String> data = null;
		Properties p = null;
		try {
			data = new HashMap<String, String>();
			p = new Properties();
			p.load(new FileReader(new File(propertiesFile)));
			for (final String name : p.stringPropertyNames())
				data.put(name, p.getProperty(name));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data;
	}
	
}
