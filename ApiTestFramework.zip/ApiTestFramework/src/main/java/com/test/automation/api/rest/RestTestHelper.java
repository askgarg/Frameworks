/**
 * 
 */
package com.amzn.automation.api.rest;

import org.apache.log4j.Logger;

import com.amzn.automation.utils.APITestBase;

/**
 * @author abhgarg
 *
 */
public class RestTestHelper extends APITestBase {
	
	public static final Logger log = Logger.getLogger(RestTestHelper.class);
	
	protected static String SRP_API_Host;
	protected static Integer SRP_API_Port;
	
	
	public static void initializeRequiredvariables() {
		try {
			SRP_API_Host = getEnvPropertyValue("srp_defalut_host");
			SRP_API_Port = Integer.parseInt(getEnvPropertyValue("srp_default_port"));
		} catch (Exception e) {
			log.error("Some variables couldNot get/Found to be Null from properties(suite/uat/prod) file");
			e.printStackTrace();
		}

	}


}
