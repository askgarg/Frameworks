/**
 * 
 */
package com.amzn.srp.backend.api.component;

import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.JsonNode;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.amzn.automation.api.rest.RestTestHelper;
import com.amzn.automation.api.rest.RestTestUtil;
import com.amzn.automation.api.rest.json.utils.JsonValidator;
import com.amzn.automation.utils.APIDataReader;

/**
 * @author abhgarg
 *
 */
public class CreateOfferAPITests extends RestTestHelper {

	static JsonNode createOfferResponse = null;

	@DataProvider(name = "CreateOffer")
	public static Object[][] getCreateTDData() throws Exception {
		return APIDataReader.getDataSetData("CREATE_OFFER");
	}

	@Test(priority = 1, dataProvider = "CreateOffer")
	public void testCreateTD(String dataGroup, String apiToExecute, String dataSetName, JsonNode jsonRequestData,
			JsonNode expectedData) throws Exception {

		Map<String, Object> headers = new HashMap<>();
		headers.put("Accept", "*/*");
		headers.put("charset", "UTF-8");
		
		createOfferResponse = RestTestUtil.sendData(apiToExecute, jsonRequestData, headers);
		boolean status = JsonValidator.DETAILED_LEVEL.validateJson(expectedData, createOfferResponse);
		Assert.assertEquals(status, true);
	}
}
